#include "Kodolvaso.h"

Kodolvaso::Kodolvaso(const std::string &be, const int erbe) :nev(be), ertek(erbe) {}

Kodolvaso::~Kodolvaso() {

}
